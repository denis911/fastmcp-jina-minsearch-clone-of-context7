from smart_home.settings import settings

__all__ = ["settings"]
